<?php
	require "db.php"; 

	if(isset($_POST['submit'])){

        $name = $_POST['name'];
        $careear = $_POST['careear'];

        $mail = $_POST['mail'];
        $address   = $_POST['address'];
        $skype_id = $_POST['skype_id'];
        $contact_number = $_POST['contact_number'];
        $linked_id = $_POST['linked_id'];
        $github_id   = $_POST['github_id'];

        $name_of_degree = $_POST['name_of_degree'];
        $institution = $_POST['institution'];
        $year   = $_POST['year'];
        $cgpa = $_POST['cgpa'];

        $role = $_POST['role'];
        $organization = $_POST['organization'];
        $time   = $_POST['time'];
        $reference_name = $_POST['reference_name'];
        $reference_phone_number = $_POST['reference_phone_number'];
        $reference_email_id   = $_POST['reference_email_id'];
        $place = $_POST['place'];

        $skills = $_POST['skills'];

        $project_name   = $_POST['project_name'];
        $project_date = $_POST['project_date'];
        $course_name = $_POST['course_name'];

        $achievements_name   = $_POST['achievements_name'];
        $achievements_date   = $_POST['achievements_date'];
        $achievements_description   = $_POST['achievements_description'];

        $languages   = $_POST['languages'];
        

		$conn = DBconnection();
        if(!$conn)
        {
            echo "DB Error: ".mysqli_connect_error();
        }else
        {
            $sql1 = "INSERT into name values('','$name','$careear')";
            $result = mysqli_query($conn, $sql1);

            $sql2 = "INSERT into contact_info values('','$mail','$address','$skype_id','$contact_number','$linked_id','$github_id')";
            $result2 = mysqli_query($conn, $sql2);

            $sql3 = "INSERT into education values('','$name_of_degree','$institution','$year','$cgpa)";
            $result3 = mysqli_query($conn, $sql3);

            $sql4 = "INSERT into workingexperience values('','$role','$organization','$time','$reference_name','$reference_phone_number','$reference_email_id','$place')";
            $result4 = mysqli_query($conn, $sql4);

            $sql5 = "INSERT into skills values('','$skills')";
            $result5 = mysqli_query($conn, $sql5);

            $sql6 = "INSERT into projects values('','$project_name','$project_date','$course_name')";
            $result6 = mysqli_query($conn, $sql6);

            $sql7 = "INSERT into achievements values('','$achievements_name','$achievements_dateh','$achievements_description')";
            $result7 = mysqli_query($conn, $sql7);

            $sql8 = "INSERT into languages values('','$languages')";
            $result8 = mysqli_query($conn, $sql8);

            header("location: index.php");
        }
	}
?>