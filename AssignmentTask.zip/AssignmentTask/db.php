<?php

	function DBconnection(){
		$conn= mysqli_connect('localhost', 'root', '', 'profile_data');
		return $conn;
	}
	

?>