<?php
    require "db.php";
    if(true)
    {
        $conn = DBconnection();
        if(!$conn)
        {
            echo "DB Error: ".mysqli_connect_error();
        }
        else
        {
            //name table
            $sql = "SELECT * from name";
            $result = mysqli_query($conn, $sql);
            while($row = mysqli_fetch_assoc($result))
            {
                $name = $row['name'];
                $objective = $row['objective'];
            }

            //contact info table
            $sql = "SELECT * from contact_info";
            $result = mysqli_query($conn, $sql);
            while($row = mysqli_fetch_assoc($result))
            {
                $mail = $row['mail'];
                $address = $row['address'];
                $skype = $row['skype'];
                $contact_number = $row['contact_number'];
                $linkedin = $row['linkedin'];
                $github = $row['github'];
            }

            $sql = "SELECT * from skills";
            $result = mysqli_query($conn, $sql);
            while($row = mysqli_fetch_assoc($result))
            {
                $skills = $row['name'];

                $skill = explode(',', $skills);
                
            }

            $sql = "SELECT * from languages";
            $result = mysqli_query($conn, $sql);
            while($row = mysqli_fetch_assoc($result))
            {
                $languages = $row['names'];

                $language = explode(',', $languages);
            }
            
        }
?>

<!DOCTYPE html>
<html>
 <head>
<link type="text/css" rel="stylesheet" href="style.css"/>
<title></title>
</head>
<body>
    <div id="header">
        <p id="name"><?php echo $name; ?></p>
    </div>
     <div class="left">

     </div>
     <div class="right">
        <h3>Career Objective</h3>
        <p><?php echo $objective; ?></p>

        <h3>Contact Information</h3>
        <table border="1">
            <tr>
                <td>
                    Mail
                </td>
                <td>
                    <?php echo $mail; ?>
                </td>
            </tr>
            <tr>
                <td>
                    Address
                </td>
                <td>
                    <?php echo $address; ?>
                </td>
            </tr>
            <tr>
                <td>
                    Skypee
                </td>
                <td>
                    <?php echo $skype; ?>
                </td>
            </tr>
            <tr>
                <td>
                    Phone Number
                </td>
                <td>
                    <?php echo $contact_number; ?>
                </td>
            </tr>
            <tr>
                <td>
                    Linkedin
                </td>
                <td>
                    <?php echo $linkedin; ?>
                </td>
            </tr>
            <tr>
                <td>
                    GitHub
                </td>
                <td>
                    <?php echo $github; ?>
                </td>
            </tr>
        </table>

        <h3>Education</h3>
        <table border="1">
            <tr id="heading">
                <th>
                    Name Of Degree
                </th>
                <th>
                    Institution
                </th>
                <th>
                    CGPA
                </th>
                <th>
                    Year
                </th>
            </tr>
<?php
        $sql = "SELECT * from education";
        $result = mysqli_query($conn, $sql);
        while($row = mysqli_fetch_assoc($result))
        {
?>
            <tr>
                <td>
                    <?php echo $row['name_of_degree']; ?>
                </td>
                <td>
                    <?php echo $row['institution']; ?>
                </td>
                <td>
                    <?php echo $row['cgpa']; ?>
                </td>
                <td>
                    <?php echo $row['year']; ?>
                </td>
            </tr>
<?php
        }
?>
        </table>

        <h3>Working Experience and Voluenteering Works</h3>
<?php
        $sql = "SELECT * from workingexperience";
        $result = mysqli_query($conn, $sql);
        while($row = mysqli_fetch_assoc($result))
        {
?>
            <h4><b>Role: <?php echo $row['role']; ?></b></h4>
            <h5>Organization: <?php echo $row['organizations']; ?></h5>
            <h6><?php echo $row['place']; ?></h6>
            <p><?php echo $row['time']; ?></p>
            <p>Contact: </p>
            <p><?php echo $row['referencename'].", ".$row['referencephonenumber'].", ".$row['reference_email'];?></p>
<?php
        }
?>

        <h3>Skills</h3>
<?php 
foreach ($skill as $sk) { ?>
    <li><?php echo $sk; ?></li>
<?php }
        
?>    
        
        <h3>Personal Project</h3>
        <?php
        $sql = "SELECT * from projects";
        $result = mysqli_query($conn, $sql);
        while($row = mysqli_fetch_assoc($result))
        {
        ?>
            <li><b><?php echo $row['name']." (".$row['date'].")"; ?></b></li>
            <p>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp <b>Course:</b> <?php echo $row['course_name']; ?>.</p>

        <?php } ?>

        <h3>Achivement(s)</h3>

        <?php
        $sql = "SELECT * from achievements";
        $result = mysqli_query($conn, $sql);
        while($row = mysqli_fetch_assoc($result))
        {
        ?>
            <li><b><?php echo $row['name']." (".$row['date'].")"; ?></b></li>
            <p>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp <b>Description:</b> <?php echo $row['description']; ?>.</p>

        <?php } ?>

        <h3>Languages</h3>
        <?php 
        foreach ($language as $lan) { ?>
            <li><?php echo $lan; ?></li>
        <?php }
                
        ?>    
     </div>
     <div id="footer"></div>
    </body>
</html>
<?php   
    }
?>
