<?php
	
	if(true){
		if($status == "invalidinput"){
			echo "Invalid Input! try again...";
		}else if($status == "nullvalue"){
			echo "The Text Fields can't be empty";
		}
	}
?>
<!DOCTYPE html>
<html>
<head>
	<title>REGISTRATION</title>
</head>
<body>
		<fieldset>
			<legend>Registration</legend>

			<form method="post" action="regCheck.php">

				User Name         : <input type="text" name="name"><br/>
				Careear Objective : <input type="text" name="careear"><br/>

				Mail              : <input type="text" name="mail"><br/>
				Address           : <input type="text" name="address"><br/>
				Skype Id          : <input type="text" name="skype_id"><br/>
				Contact Number    : <input type="text" name="contact_number"><br/>
				Linkedin_id       : <input type="text" name="linked_id"><br/>
				Github_id         : <input type="text" name="github_id"><br/>

				Name Of Degree    : <input type="text" name="name_of_degree"><br/>
				institution       : <input type="text" name="institution"><br/>
				Year              : <input type="text" name="year"><br/>
				CGPA              : <input type="text" name="cgpa"><br/>

				Role              : <input type="text" name="role"><br/>
				Organizations     : <input type="text" name="organizations"><br/>
				Time              : <input type="text" name="time"><br/>
				Reference_Name    : <input type="text" name="reference_name"><br/>
				Reference_Phone_number  : <input type="text" name="reference_phone_number"><br/>
				Reference_Email_Id: <input type="text" name="reference_email_id"><br/>
				Place             : <input type="text" name="place"><br/>

				Skills            : <input type="text" name="skills"><br/>

			    Project_Name      : <input type="text" name="project_name"><br/>
			    Project_Date      : <input type="date" name="project_date"><br/>
			    Course_Name       : <input type="text" name="course_name"><br/>

			    Achievements_Name : <input type="text" name="achievements_name"><br/>
			    Achievements_Date: <input type="date" name="achievements_date"><br/>
			    Achievements_Description: <input type="text" name="achievements_description"><br/>

				Languages		  : <input type="text" name="languages"><br/>

						    		<input type="submit" name="submit" value="Submit">
			</form>
		</fieldset>
</body>
</html>